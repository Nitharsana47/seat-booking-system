for ($i = 0; $i -lt 20; $i++) {
    docker ps > $null 2>&1
    if ($LastExitCode -eq 0) {
        Write-Output "Docker is ready"
        exit 0
    }
    Write-Output "Waiting for Docker daemon to start... ($i/20)"
    Start-Sleep -Seconds 3
}
Write-Output "Docker daemon failed to start in time."
exit 1
